from app.config import FLAG

def get_flag() -> str:
    return FLAG

