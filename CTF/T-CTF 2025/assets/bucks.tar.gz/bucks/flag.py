from bucks.context import Context

async def get_flag(context: Context) -> str:
    if context.bought is not None:
        return "tctf{<CENSORED>}"
