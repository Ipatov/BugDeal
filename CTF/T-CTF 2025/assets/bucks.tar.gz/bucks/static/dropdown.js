window.addEventListener('load', function() {
    document.querySelectorAll('.selectbox').forEach(selectbox => {
        const displayWrapper = selectbox.querySelector('.display-wrapper');
        const display = selectbox.querySelector('.display');
        const dropdown = selectbox.querySelector('.dropdown');
        const hiddenInput = selectbox.querySelector('input[type="hidden"]');

        function callback() {
            const target = selectbox.getAttribute('data-onselect');

            if (!target) return;

            (function(value) {
                eval(target);
            })(hiddenInput.value);
        }

        if (hiddenInput.value) {
            display.innerHTML = dropdown.querySelector(`[data-value="${hiddenInput.value}"]`).innerHTML;
            callback();
        }

        displayWrapper.addEventListener('click', function(e) {
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        });

        for (const item of dropdown.children) {
            item.addEventListener('click', function() {
                display.innerHTML = item.innerHTML;
                hiddenInput.value = item.getAttribute('data-value');
                dropdown.style.display = 'none';
                callback();
            });
        }

        document.addEventListener('click', function(ev) {
            if (!selectbox.contains(ev.target)) {
                dropdown.style.display = 'none';
            }
        });
    });
});
