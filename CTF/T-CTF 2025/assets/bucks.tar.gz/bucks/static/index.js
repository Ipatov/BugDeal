const img = document.querySelector('#background');
const overlay = document.querySelector('#overlay');
const svg = document.querySelector('#overlay > svg');
const tooltip = document.querySelector('#tooltip');
const root = document.querySelector('#root');
const highlight = document.querySelector('#highlight');
const door = svg.querySelector('#door');
const banknote = svg.querySelector('#banknote');

function updateOverlay() {
  const naturalWidth = img.naturalWidth;
  const naturalHeight = img.naturalHeight;
  if (!naturalWidth || !naturalHeight) {
    return;
  }

  svg.setAttribute('viewBox', `0 0 ${naturalWidth} ${naturalHeight}`);

  const rect = img.getBoundingClientRect();
  overlay.style.width = rect.width + 'px';
  overlay.style.height = rect.height + 'px';

  root.style.width = rect.width + 'px';
  root.style.height = rect.height + 'px';
}

function polygonMouseOver(evt) {
  const polygon = evt.target;
  const tooltipText = polygon.getAttribute('data-tooltip');
  tooltip.textContent = tooltipText;
  tooltip.style.display = 'block';

  const bbox = polygon.getBBox();
  const centerX = bbox.x + bbox.width / 2;
  const topY = bbox.y;

  let pt = svg.createSVGPoint();
  pt.x = centerX;
  pt.y = topY;
  const screenCTM = svg.getScreenCTM();
  if (screenCTM) {
    pt = pt.matrixTransform(screenCTM);
  }

  const containerRect = root.getBoundingClientRect();

  const tooltipX = pt.x - containerRect.left - (tooltip.offsetWidth / 2);
  const tooltipY = pt.y - containerRect.top - tooltip.offsetHeight - 10;
  tooltip.style.left = tooltipX + 'px';
  tooltip.style.top = tooltipY + 'px';
}

function polygonMouseOut() {
  tooltip.style.display = 'none';
}

function initialize() {
  updateOverlay();

  if (window.initialized) {
    return;
  }

  window.initialized = true;

  svg.querySelectorAll('polygon').forEach(polygon => {
    polygon.addEventListener('mouseover', polygonMouseOver);
    polygon.addEventListener('mouseout', polygonMouseOut);
  });

  door.addEventListener('click', () => {
    window.location.href = '/cashier';
  });

  banknote.addEventListener('mouseover', () => {
    highlight.style.opacity = '1';
  });

  banknote.addEventListener('mouseout', () => {
    highlight.style.opacity = '0';
  });

  banknote.addEventListener('click', () => {
    fetch('/take', { method: 'POST' })
      .then((resp) => {
        if (resp.status === 200) {
            alert('Вы нашли: 100 КАПИБАКСОВ');
            highlight.style.display = 'none';
            tooltip.style.display = 'none';
            banknote.parentElement.removeChild(banknote);
            document.querySelector('#banknote-layer').style.display = 'none';
        } else {
            alert('Ошибка!');
        }
      });
  });
}

window.addEventListener('load', initialize);
img.addEventListener('load', initialize);s

window.addEventListener('resize', updateOverlay);
