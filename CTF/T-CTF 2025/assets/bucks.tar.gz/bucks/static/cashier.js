const labels = document.querySelectorAll('.exchange > label');
const amount = document.querySelector('#amount');
const maxAmount = document.querySelector('#max-amount');

async function updateCurrency(currency) {
    const resp = await fetch(`/currency/${currency}`);
    if (resp.status !== 200) {
        alert('Ошибка!');
        return;
    }
    const data = await resp.json();

    window.currency = data.currency;
    window.balance = data.balance;

    amount.max = data.balance;
    maxAmount.textContent = `${data.balance} ${data.currency}`;

    for (let idx = 0; idx < data.rates.length; idx++) {
        if (data.rates[idx] === null) {
            labels[idx].style.display = 'none';
            continue;
        }

        labels[idx].style.display = 'table-row';

        let rate = 1 / data.rates[idx];
        let denominator = 1;

        while (rate < 1) {
            rate *= 100;
            denominator *= 100;
        }

        labels[idx].querySelector('.rate').textContent = Math.round(rate * 1000) / 1000;
        labels[idx].querySelector('.denominator').textContent = denominator;
    }

    syncFinalize();
}

document.querySelectorAll('input[type=radio]').forEach(radio => {
    radio.addEventListener('change', () => {
        window.targetChosen = radio.value;
        syncFinalize();
    })
});

window.addEventListener('load', function() {
    const selected = document.querySelector('input[type=radio]:checked');
    if (selected) {
        window.targetChosen = selected.value;
        syncFinalize();
    }
})

const finalize = document.querySelector('.finalize');
const notCompleted = document.querySelector('.not-completed');
function syncFinalize() {
    const show = window.balance >= 0.01 && window.targetChosen && window.targetChosen !== window.currency;
    if (show) {
        finalize.style.display = 'block';
        notCompleted.style.display = 'none';
    } else {
        finalize.style.display = 'none';
        notCompleted.style.display = 'block';
    }
}
