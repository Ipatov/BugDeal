import math
import logging
import os
from typing import Annotated

from fastapi import FastAPI, Form, HTTPException, Request, Response
from fastapi.middleware import Middleware
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.sessions import SessionMiddleware

from bucks.context import AppContext, Context, app_lifespan
from bucks.currency import CurrencyCode, exchange_rate, RATES
from bucks.flag import get_flag

app = FastAPI(
    docs_url=None,
    redoc_url=None,
    lifespan=app_lifespan,
    middleware=[
        Middleware(SessionMiddleware, secret_key=os.environ["SECRET_KEY"])
    ]
)

logger = logging.getLogger("gunicorn.error")


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException) -> Response:
    print(exc.headers)
    context = AppContext(request)
    return context.render(
        "error.html",
        {"exception": str(exc.detail), "status_code": exc.status_code},
        status_code=exc.status_code,
        headers=exc.headers
    )


@app.get("/")
async def index(context: Context) -> Response:
    if context.has_balances:
        return RedirectResponse("/cashier", status_code=303)
    return context.render("index.html", {})


@app.post("/take")
async def take(context: Context) -> Response:
    if context.has_balances:
        return Response("Already has money", status_code=400)
    context.reset_balance()
    logger.info("%s RESET", context.user_info())

    return Response("OK")


@app.get("/cashier")
async def cashier(context: Context) -> Response:
    return context.render("cashier.html", {})


class ExchangeRequest(BaseModel):
    source_currency: CurrencyCode
    target_currency: CurrencyCode
    amount: float

@app.post("/exchange")
async def exchange(
    context: Context,
    request: Annotated[ExchangeRequest, Form()]
) -> Response:
    amount = round(request.amount, 2)

    if request.source_currency == request.target_currency or amount <= 0 or not math.isfinite(amount):
        raise HTTPException(400, detail="Некорректная операция")

    if amount > context.balances[request.source_currency.index]:
        raise HTTPException(400, detail="Недостаточно средств")

    rate = exchange_rate(request.source_currency, request.target_currency)

    context.balances[request.source_currency.index] -= amount
    context.balances[request.target_currency.index] += amount * rate
    logger.info("%s exchanged %.12f %s to %.12f %s", context.user_info(), request.amount, request.source_currency, request.amount * rate, request.target_currency)

    return RedirectResponse("/cashier", status_code=303)


@app.get("/currency/{currency}")
async def currency(context: Context, currency: CurrencyCode) -> Response:
    rates = RATES[currency.index]

    return JSONResponse({
        "balance": context.balances[currency.index],
        "currency": currency,
        "sign": currency.sign,
        "rates": rates
    })


@app.get("/franchise")
async def buy_franchise(context: Context) -> Response:
    try:
        context.buy_franchise()
    except ValueError:
        raise HTTPException(400, detail="Недостаточно средств")

    flag = await get_flag(context)

    return context.render("franchise.html", {"flag": flag})


@app.get("/exit")
async def exit(context: Context) -> Response:
    context.drop_balance()
    return RedirectResponse("/", status_code=303)
