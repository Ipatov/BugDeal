from dataclasses import dataclass
from enum import StrEnum


class CurrencyCode(StrEnum):
    CAB = "CAB"
    MGA = "MGA"
    AFN = "AFN"
    THB = "THB"
    BTC = "BTC"
    BOB = "BOB"
    ETB = "ETB"
    VUV = "VUV"
    KPW = "KPW"
    PYG = "PYG"
    HTG = "HTG"
    GMD = "GMD"
    JOD = "JOD"
    MAD = "MAD"
    STN = "STN"
    VND = "VND"
    AMD = "AMD"
    PLN = "PLN"
    JPY = "JPY"
    AOA = "AOA"
    ZMW = "ZMW"
    GTQ = "GTQ"
    LAK = "LAK"
    ISK = "ISK"
    GEL = "GEL"
    BGN = "BGN"
    HNL = "HNL"
    SLL = "SLL"
    TRY = "TRY"
    AZN = "AZN"
    BAM = "BAM"
    MZN = "MZN"
    NGN = "NGN"
    BTN = "BTN"
    PHP = "PHP"
    BWP = "BWP"
    KHR = "KHR"
    MYR = "MYR"
    INR = "INR"
    GHS = "GHS"
    TJS = "TJS"
    VES = "VES"
    BDT = "BDT"
    KZT = "KZT"
    MNT = "MNT"
    AWG = "AWG"
    BIF = "BIF"
    SHP = "SHP"
    ILS = "ILS"
    SOS = "SOS"

    @property
    def index(self) -> int:
        return CURRENCIES[self].index

    @property
    def name(self) -> str:
        return CURRENCIES[self].name

    @property
    def sign(self):
        return CURRENCIES[self].sign

    def __repr__(self) -> str:
        return self.value

    def __str__(self) -> str:
        return self.value

    @classmethod
    def all(cls) -> list["CurrencyCode"]:
        return list(cls)


@dataclass
class Currency:
    index: int
    name: str
    sign: str


CURRENCIES = {
    CurrencyCode.CAB: Currency(0, "Капибакс", "₡"),
    CurrencyCode.MGA: Currency(1, "Малагасийский ариари", "Ar."),
    CurrencyCode.AFN: Currency(2, "Афгани", "؋"),
    CurrencyCode.THB: Currency(3, "Тайский бат", "฿"),
    CurrencyCode.BTC: Currency(4, "Сальвадорский биткоин", "₿"),
    CurrencyCode.BOB: Currency(5, "Боливиано", "$"),
    CurrencyCode.ETB: Currency(6, "Эфиопский быр", "Br"),
    CurrencyCode.VUV: Currency(7, "Вату", "Vt"),
    CurrencyCode.KPW: Currency(8, "Северокорейская вона", "원"),
    CurrencyCode.PYG: Currency(9, "Парагвайский гуарани", "₲"),
    CurrencyCode.HTG: Currency(10, "Гаитянский гурд", "G"),
    CurrencyCode.GMD: Currency(11, "Даласи", "D"),
    CurrencyCode.JOD: Currency(12, "Иорданский динар", ".د.إ"),
    CurrencyCode.MAD: Currency(13, "Марокканский дирхам", ".د.م"),
    CurrencyCode.STN: Currency(14, "Добра Сан-Томе и Принсипи", "Db"),
    CurrencyCode.VND: Currency(15, "Вьетнамский донг", "₫"),
    CurrencyCode.AMD: Currency(16, "Армянский драм", "֏"),
    CurrencyCode.PLN: Currency(17, "Польский злотый", "zł"),
    CurrencyCode.JPY: Currency(18, "Японская йена", "¥"),
    CurrencyCode.AOA: Currency(19, "Ангольская кванза", "Kz"),
    CurrencyCode.ZMW: Currency(20, "Замбийская квача", "K"),
    CurrencyCode.GTQ: Currency(21, "Гватемальский кетсаль", "Q"),
    CurrencyCode.LAK: Currency(22, "Лаосский кип", "₭"),
    CurrencyCode.ISK: Currency(23, "Исландская крона", "kr"),
    CurrencyCode.GEL: Currency(24, "Грузинский лари", "₾"),
    CurrencyCode.BGN: Currency(25, "Болгарский лев", "лв"),
    CurrencyCode.HNL: Currency(26, "Гондурасская лемпира", "L"),
    CurrencyCode.SLL: Currency(27, "Леоне", "Le"),
    CurrencyCode.TRY: Currency(28, "Турецкая лира", "₺"),
    CurrencyCode.AZN: Currency(29, "Азербайджанский манат", "₼"),
    CurrencyCode.BAM: Currency(30, "Конвертируемая марка", "KM"),
    CurrencyCode.MZN: Currency(31, "Мозамбикский метикал", "MT"),
    CurrencyCode.NGN: Currency(32, "Найра", "₦"),
    CurrencyCode.BTN: Currency(33, "Нгултрум", "Nu"),
    CurrencyCode.PHP: Currency(34, "Филиппинское песо", "₱"),
    CurrencyCode.BWP: Currency(35, "Ботсванская пула", "P"),
    CurrencyCode.KHR: Currency(36, "Камбоджийский риель", "៛"),
    CurrencyCode.MYR: Currency(37, "Малайзийский ринггит", "RM"),
    CurrencyCode.INR: Currency(38, "Индийская рупия", "₹"),
    CurrencyCode.GHS: Currency(39, "Ганский седи", "₵"),
    CurrencyCode.TJS: Currency(40, "Таджикский сомони", "с."),
    CurrencyCode.VES: Currency(41, "Суверенный боливар", "Bs. S."),
    CurrencyCode.BDT: Currency(42, "Бангладешская така", "৳"),
    CurrencyCode.KZT: Currency(43, "Казахстанский тенге", "₸"),
    CurrencyCode.MNT: Currency(44, "Монгольский тугрик", "₮"),
    CurrencyCode.AWG: Currency(45, "Арубанский флорин", "ƒ"),
    CurrencyCode.BIF: Currency(46, "Бурундийский франк", "₣"),
    CurrencyCode.SHP: Currency(47, "Фунт Святой Елены", "£"),
    CurrencyCode.ILS: Currency(48, "Новый израильский шекель", "₪"),
    CurrencyCode.SOS: Currency(49, "Сомалийский шиллинг", "S")
}


RATES = [
    # CENSORED 50x50 float array
    # RATES[i][i] is None for all i
]

RATES_INV = [[RATES[v][u] for v in range(len(RATES))] for u in range(len(RATES))]

START_BALANCE = [100] + [0] * (len(RATES) - 1)
WIN_COST = 13337


def exchange_rate(src: CurrencyCode, dst: CurrencyCode) -> float:
    return RATES[src.index][dst.index]


__all__ = ["CurrencyCode", "RATES", "RATES_INV", "START_BALANCE", "WIN_COST", "exchange_rate"]
