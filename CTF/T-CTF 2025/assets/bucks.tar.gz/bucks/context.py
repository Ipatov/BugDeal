import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated

import jinja2
import numpy as np  # Sorry.
from fastapi import Depends, FastAPI, Request, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from bucks.currency import START_BALANCE, WIN_COST, CurrencyCode

app_root = Path(__file__).parent

template_env = jinja2.Environment(
    loader=jinja2.FileSystemLoader(app_root / "templates"),
    autoescape=True
)
templates = Jinja2Templates(env=template_env)

def float(x: float, precision: int = 12) -> str:
    return np.format_float_positional(x, precision=precision, trim='-')

template_env.filters["float"] = float


class AppContext:
    def __init__(self, request: Request):
        if "user_id" not in request.session:
            request.session["user_id"] = secrets.token_hex(16)

        self.request = request
        self.user_id = request.session["user_id"]
        self.balances = request.session.get("balances", [0] * len(CurrencyCode))
        self.has_balances = "balances" in request.session
        self.context = {"balances": self.balances, "currencies": CurrencyCode.all(), "WIN_COST": WIN_COST}
        self.bought = None

    def reset_balance(self) -> None:
        self.request.session["balances"] = START_BALANCE.copy()

    def drop_balance(self) -> None:
        self.request.session.pop("balances", None)

    def buy_franchise(self) -> None:
        if "franchise" in self.request.session:
            self.bought = False
            return

        if self.balances[0] < WIN_COST:
            raise ValueError("Not enough money")
        self.balances[0] -= WIN_COST
        self.request.session["franchise"] = True
        self.bought = True

    def user_info(self) -> str:
        return f"{self.user_id}"

    def render(self, template_name: str, context: dict | None = None, **kwargs) -> Response:
        """Renders a template with the base context and additional context if provided"""
        if context is not None:
            self.context.update(**context)
        return templates.TemplateResponse(
            request=self.request,
            name=template_name,
            context=self.context,
            **kwargs
        )

Context = Annotated[AppContext, Depends()]


async def setup(app: FastAPI):
    app.mount("/static", StaticFiles(directory=app_root / "static"), name="static")


@asynccontextmanager
async def app_lifespan(app: FastAPI):
    await setup(app)
    yield


__all__ = ["app_lifespan", "AppContext", "Context"]
