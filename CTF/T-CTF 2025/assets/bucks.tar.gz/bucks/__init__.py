from dotenv import load_dotenv

load_dotenv()

def run():
    import sys
    from bucks.gunicorn import BucksApplication
    if len(sys.argv) > 1:
        workers = int(sys.argv[1])
    else:
        workers = None

    BucksApplication(workers).run()


def debug():
    import uvicorn
    uvicorn.run("bucks.app:app", reload=True, port=8000)
